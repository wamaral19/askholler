# Holler design system

Files: `tokens.css` (CSS variables, font faces and type classes — link it and use `var(--holler-blue)`, `class="body"` etc.), `tokens.json` (the same tokens as data), `fonts/` (Source Serif 4, SIL Open Font License), `logos/` (transparent PNGs).

Holler runs point-in-time customer research: a shopper finishes a moment — checkout, a delivery — and a real person talks with them right then. The identity is a bookish serif with one bright blue and a warm cream colon: human, literate, a little loud.

## Name

- Always write **Holler** with a capital H, in prose and in the logo.
- The colon in the logo stands for a conversation between two people (1:1). Don't add a colon to the name when typing it.

## Logo

- **Primary wordmark** (`logos/holler-wordmark.png`): "Holler" set in Iowan Old Style, with a cream colon between the two l's, which are drawn as 1s. Use it wherever the brand is introduced — site header, decks, email footers.
- **Primary logo** (`logos/holler-mark.png`): the 1:1 — the two l's and the colon. Use it where space is square or small: app icon, avatar, favicon, social profile.
- Place both on `surface`, `surface-raised` or `night`. Never on `holler-blue` (the blue letters disappear) or on busy photography.
- Clear space: at least the height of one colon ring on every side.
- Minimum size: wordmark 96px wide; mark 24px tall. Below that, set "Holler" in `heading-3` instead.
- Don't recolor, outline, stretch, rotate, add shadows, or rebuild the mark from a font — always use the supplied files.

## Color

- `holler-blue` is the brand. Use it big: primary buttons, the wordmark, hero fills, charts' lead series. It is too light for text on light grounds (2.7:1) — set blue text in `blue-ink`.
- Text on a `holler-blue` fill is always `on-holler-blue` (night), never white.
- `cream` is the colon: a warm highlight for pull quotes, callouts, tags and selected rows. Text on it is `on-cream`.
- `night` is the tertiary: a deep navy for footers, hero bands and feature panels. Both `holler-blue` and `cream` read on it; it is also the dark theme's ground.
- Neutrals are warm and navy-tinted: body text in `ink` on `surface`, secondary text in `ink-muted`, hairlines in `line`, control borders in `line-strong`.
- Proportion: mostly `surface` and `ink`, a clear hit of `holler-blue`, cream as a spice. Never set cream and blue side by side as equal-weight fills.

## Typography

- **Iowan Old Style** (the `display` family) is the primary face — headings, the display line and anything that speaks as the brand. It ships with macOS and iOS; other systems fall back to Palatino, then Georgia. Keep it at regular weight above 24px; use bold only at `heading-3`.
- **Source Serif 4** (the `text` family) is the secondary face — body copy, UI, tables and labels. It is bundled with this system, so reading text looks the same on every device.
- Styles: `display` once per page; `heading-1` page titles; `heading-2` sections; `heading-3` cards. `body` is the default; `body-lg` for lead paragraphs; `body-sm` for dense UI; `label` for buttons, tags and eyebrows; `caption` (italic) for quote attributions and timestamps.
- Sentence case everywhere — headings, buttons, menu items. Uppercase only for `label` eyebrows.
- Shopper quotes are the hero content: set them in `body-lg` or `heading-2`, with curly quotes and a `caption` attribution that says when the conversation happened ("— first-time buyer, 4 min after checkout").

## Space and shape

- Spacing runs on a 4px base: `space-2` inside controls, `space-4` default gaps, `space-6` card padding, `space-12` between sections.
- Corners: `radius-sm` for inputs and tags, `radius-md` for buttons and cards, `radius-lg` for hero panels, `radius-full` for pills.
- Separate with `line` hairlines and space, not shadows.
- The ring — the colon's hollow dot — is the brand's one graphic motif. Use it sparingly: as a bullet, a status dot, or a pair of rings marking a quote. Never as wallpaper.

## Interaction

- Primary button: `holler-blue` fill, `on-holler-blue` label in `label` at 15px, `radius-md`, `space-3` × `space-5` padding.
- Secondary button: `surface-raised` fill, `line-strong` border, `ink` label.
- Links: `link`, underlined.
- Focus: a 2px solid `focus-ring` outline, offset 2px, on every interactive element.

## Voice

- Human first: we talk about people and conversations, not "respondents" or "data points".
- Plain and warm. Short sentences, active verbs, no jargon.
- Let customers do the talking — quote them before summarizing them.
- No emoji in product UI.
